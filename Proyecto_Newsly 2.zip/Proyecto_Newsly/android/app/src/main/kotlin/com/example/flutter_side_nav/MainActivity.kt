package com.example.flutter_side_nav

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
