import 'package:flutter/material.dart';

import 'ui/app.dart';

void main() {
  runApp(const App());
}
