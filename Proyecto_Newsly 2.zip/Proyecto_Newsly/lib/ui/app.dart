import 'package:flutter/material.dart';
import 'package:flutter_side_nav/ui/pages/login.dart';
import 'pages/login.dart';
import 'pages/register.dart';
import 'pages/chat_page.dart';
import 'pages/home_page.dart';

class App extends StatefulWidget {
  const App({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _AppState();
  }
}

class _AppState extends State<App> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      debugShowCheckedModeBanner: false,
      routes: {
        '/': (context) => const LoginPage(
              title: 'Iniciar Sesion',
            ),
        '/register': (context) => const RegisterPage(
              title: 'Registrarse',
            ),
        '/home': (context) => const HomePage(
              title: 'Estados',
            ),
        '/chat': (context) => const ChatPage(
              title: 'Chat',
            ),
      },
    );
  }
}
