import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  void _login() {
    setState(() {
      Navigator.pushNamed(context, '/home');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Text(""),
          const Text(""),
          Center(
              child: SizedBox(
            width: 100,
            height: 100,
            child: Image.network(
                "https://cdn.pixabay.com/photo/2012/04/11/11/55/letter-n-27733_960_720.png"),
          )),
          const Text(""),
          Center(
            child: Container(
              margin: const EdgeInsets.all(20.0),
              child: const TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Usuario',
                ),
              ),
            ),
          ),
          Center(
            child: Container(
              margin: const EdgeInsets.all(20.0),
              child: const TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Contraseña',
                ),
              ),
            ),
          ),
          const Text(""),
          const Text(""),
          Center(
            child: MaterialButton(
              color: Colors.grey.shade900,
              textColor: Colors.grey.shade50,
              child: const Text('Iniciar Sesion'),
              onPressed: () {
                Navigator.pushNamed(context, '/home');
              },
            ),
          ),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Text(""),
          const Center(
            child: Text("¿No tienes cuenta?"),
          ),
          const Text(""),
          Center(
            child: MaterialButton(
              color: Colors.grey.shade900,
              textColor: Colors.grey.shade50,
              child: const Text('Registrarse'),
              onPressed: () {
                Navigator.pushNamed(context, '/register');
              },
            ),
          ),
        ],
      ),
    );
  }
}
