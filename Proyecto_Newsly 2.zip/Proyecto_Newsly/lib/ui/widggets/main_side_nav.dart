import 'package:flutter/material.dart';

class MainSideNavDrawer extends StatelessWidget {
  const MainSideNavDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          const DrawerHeader(
            child: Center(
                child: Text(
              'Newsly',
              style: TextStyle(
                  fontFamily: "newsly",
                  package: 'flutter_side_nav',
                  color: Colors.white,
                  fontSize: 25),
            )),
            decoration: BoxDecoration(
              color: Colors.black87,
              image: DecorationImage(
                fit: BoxFit.fill,
                image: AssetImage('', package: 'flutter_side_nav'),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.post_add),
            title: const Text('Estados'),
            onTap: () => {Navigator.of(context).pushNamed('/')},
          ),
          ListTile(
            leading: const Icon(Icons.chat),
            title: const Text('Chats'),
            onTap: () => {Navigator.of(context).pushNamed('/chat')},
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Configuracion'),
            onTap: () => {Navigator.of(context).pop()},
          ),
          ListTile(
            leading: const Icon(Icons.exit_to_app),
            title: const Text('Cerrar Sesion'),
            onTap: () => {Navigator.of(context).pushNamed('/')},
          ),
        ],
      ),
    );
  }
}
