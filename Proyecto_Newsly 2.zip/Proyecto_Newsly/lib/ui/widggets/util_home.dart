import 'package:flutter/material.dart';

class HomeWidget extends StatefulWidget {
  const HomeWidget({Key? key}) : super(key: key);

  @override
  State<HomeWidget> createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> {
  // Listado de cadenas
  var listado = [
    Persona(
        "Universidad del norte",
        "User 1",
        "Ya la mitad de la poblacion colombiana se encuentra vacunada",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-2LBGfGpmnTNxLEkwg3wFM3HN-_0sGQdt9j186NBoCpTFfoHj68ksGHptbfyZbf4ienk&usqp=CAU"),
    Persona(
        "Universidad libre",
        "User 2",
        "Inseguridad en barrios de bogota/colombia",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-2LBGfGpmnTNxLEkwg3wFM3HN-_0sGQdt9j186NBoCpTFfoHj68ksGHptbfyZbf4ienk&usqp=CAU"),
    Persona("Universidad del magdalena", "User 3", "Huracan de 4.4 en japon",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-2LBGfGpmnTNxLEkwg3wFM3HN-_0sGQdt9j186NBoCpTFfoHj68ksGHptbfyZbf4ienk&usqp=CAU"),
    Persona(
        "Universidad simon bolivar",
        "User 4",
        "Fuertes derrumbes en santander/colombia",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-2LBGfGpmnTNxLEkwg3wFM3HN-_0sGQdt9j186NBoCpTFfoHj68ksGHptbfyZbf4ienk&usqp=CAU"),
    Persona(
        "Universidad javeriana",
        "User 5",
        "Se reporta una persona desaparecida",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-2LBGfGpmnTNxLEkwg3wFM3HN-_0sGQdt9j186NBoCpTFfoHj68ksGHptbfyZbf4ienk&usqp=CAU"),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
            flex: 0,
            child: Row(
              children: [
                // Barra de Busqueda
                Expanded(
                  flex: 9,
                  child: Container(
                    margin: const EdgeInsets.all(20.0),
                    child: const TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Buscar Post',
                      ),
                    ),
                  ),
                ),
              ],
              //
            )),
        // Lista de Post
        Expanded(
          flex: 5,
          child: ListView.builder(
            itemCount: listado.length,
            itemBuilder: (context, i) {
              return Card(
                margin: const EdgeInsets.fromLTRB(20, 5, 20, 5),
                child: Row(
                  children: [
                    Image.network(listado[i].img),
                    Expanded(
                      flex: 330,
                      child: Container(
                        padding: const EdgeInsets.all(1.0),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Text(
                                  "Nombre: ",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                Text(listado[i].name),
                                const Spacer(),
                                const Text(
                                  "Egresado: ",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                Text(listado[i].id),
                              ],
                            ),
                            const Text(
                              "Reportaje:",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text(listado[i].desc),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class Persona {
  late String id;
  late String name;
  late String desc;
  late String img;

  Persona(this.id, this.name, this.desc, this.img);
}
