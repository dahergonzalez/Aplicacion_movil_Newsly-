package com.example.red_social

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
